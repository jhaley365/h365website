/**
 * Haley365 — Homepage (Direction 1a: "Safe / evolve current")
 * ------------------------------------------------------------
 * Production-ready React component. Framework-agnostic (works in Next.js
 * app router as app/page.jsx, or as a component in any React app).
 *
 * FONTS: load these once (e.g. in app/layout.jsx <head> or via next/font):
 *   Archivo (600/700/800), IBM Plex Sans (400/500/600/700), IBM Plex Mono (500/600)
 *   Material Symbols Rounded (for icons)
 *   <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;700;800&family=IBM+Plex+Mono:wght@500;600&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet" />
 *   <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
 *
 * ADAPTATION NOTES for Claude Code:
 *   - Inline styles are used for a faithful, dependency-free reference.
 *     Convert to your project's convention (Tailwind classes / CSS Modules /
 *     styled-components). The exact token values are in the handoff README.
 *   - Replace <Icon/> (Material Symbols) with your icon library if preferred.
 *   - Wire the CTAs / nav links to real routes. "Client Login" -> https://portal.haley365.com/ (new tab).
 *   - The hero grid overlay + radial glows are decorative; keep as CSS.
 */

const ACCENT = "#2f6bff";

const CAPABILITIES = [
  {
    icon: "smart_toy",
    title: "AI & Custom Apps",
    body: "Custom software and AI workflows that automate the busywork and fit how your team operates.",
  },
  {
    icon: "shield",
    title: "Managed Security",
    body: "24/7 threat detection, EDR, and a hardened posture that keeps you audit-ready and protected.",
  },
  {
    icon: "cloud",
    title: "Cloud Infrastructure",
    body: "Design, migration, and management of resilient cloud environments that scale with you.",
  },
  {
    icon: "support_agent",
    title: "Managed IT & Service Desk",
    body: "A human-centric help desk that keeps your people productive and your systems current.",
  },
];

const STATS = [
  { value: "24/7", label: "Security operations" },
  { value: "99.9%", label: "Monitored uptime" },
  { value: "1,200+", label: "Endpoints managed" },
];

const WHY_POINTS = [
  "One partner across IT, security, cloud, and software",
  "SMB-focused, senior-level engineering",
  "Transparent reporting through your client portal",
];

// Consultation form — destination address is server-side config in production.
const CONSULT_EMAIL = "contact@haley365.com";
const CONSULT_INTERESTS = [
  "General inquiry",
  "AI & custom applications",
  "Managed security",
  "Cloud infrastructure",
  "Managed IT & service desk",
];

const ABOUT_STATS = [
  { value: "20+", label: "Years in business" },
  { value: "30+", label: "Years combined IT experience" },
  { value: "15+", label: "Years building custom applications" },
];

const ABOUT_VALUES = [
  { icon: "verified_user", title: "Security in our DNA", body: "SANS-trained and certified, we start every engagement from a hardened posture — not an afterthought bolted on later." },
  { icon: "engineering", title: "Certified, senior engineers", body: "Certified across networking, AWS, Microsoft Server, and Microsoft 365 — you work with experienced people, not endless ticket tiers." },
  { icon: "terminal", title: "Custom solutions specialists", body: "15+ years building custom applications means we solve the problem in front of you — not the one the software vendor assumed." },
];

const ABOUT_CERTS = [
  { icon: "lan", label: "Networking" },
  { icon: "cloud", label: "Amazon AWS" },
  { icon: "dns", label: "Microsoft Server" },
  { icon: "mail", label: "Microsoft 365" },
  { icon: "shield", label: "SANS Cybersecurity" },
];

function Icon({ name, style }) {
  return (
    <span
      className="material-symbols-rounded"
      style={{ fontFamily: "'Material Symbols Rounded'", lineHeight: 1, ...style }}
    >
      {name}
    </span>
  );
}

function Logo() {
  return (
    <a href="/" style={{ display: "flex", alignItems: "center", gap: 11, textDecoration: "none" }}>
      <svg width="34" height="34" viewBox="0 0 48 48" fill="none" style={{ flex: "none" }}>
        <g transform="rotate(-28 24 24)">
          <ellipse cx="24" cy="24" rx="18" ry="8.5" stroke="#3b82f6" strokeWidth="2.2" fill="none" />
          <circle cx="42" cy="24" r="3.2" fill="#3b82f6" />
        </g>
        <circle cx="24" cy="24" r="4.4" fill="#fff" />
      </svg>
      <span style={{ display: "flex", flexDirection: "column", lineHeight: 1 }}>
        <span style={{ fontFamily: "'Archivo',sans-serif", fontWeight: 800, letterSpacing: "0.16em", fontSize: 17, color: "#fff" }}>
          HALEY365
        </span>
        <span style={{ fontSize: 8.5, letterSpacing: "0.24em", color: "#7f8ea3", marginTop: 4 }}>
          ALWAYS-ON IT &amp; SECURITY
        </span>
      </span>
    </a>
  );
}

const inputStyle = { width: "100%", padding: "11px 12px", background: "#0a0f1a", border: "1px solid rgba(255,255,255,0.14)", borderRadius: 9, color: "#eaf0fb", fontFamily: "inherit", fontSize: 14, boxSizing: "border-box" };
const labelStyle = { display: "block", fontSize: 12, fontWeight: 600, color: "#c4cede", marginBottom: 6 };

/**
 * Consultation modal. PROTOTYPE composes a mailto: link so the demo works with no backend.
 * PRODUCTION: POST to a server route (e.g. /api/consultation) that sends the email server-side
 * over SMTP via Nodemailer. Relay (client-confirmed): host mail.smtp2go.com, port 25, NO auth.
 * To: contact@haley365.com, replyTo: visitor's email. Keep host/port/to in env vars so the relay
 * is swappable (port 2525 + STARTTLS + API-key is the fallback if 25 is blocked). Add validation,
 * honeypot/CAPTCHA, and rate limiting. See README "Email delivery" for a Nodemailer example.
 */
function ConsultModal({ open, onClose }) {
  const [submitted, setSubmitted] = React.useState(false);
  React.useEffect(() => { if (open) setSubmitted(false); }, [open]);
  React.useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    if (open) document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    // TODO(production): replace this mailto with a fetch POST to your email API route.
    const subject = encodeURIComponent("Consultation request — " + (fd.get("company") || fd.get("name") || ""));
    const body = encodeURIComponent(
      "Name: " + (fd.get("name") || "") + "\nWork email: " + (fd.get("email") || "") +
      "\nCompany: " + (fd.get("company") || "") + "\nPhone: " + (fd.get("phone") || "") +
      "\nInterested in: " + (fd.get("interest") || "") + "\n\n" + (fd.get("message") || "")
    );
    window.location.href = "mailto:" + CONSULT_EMAIL + "?subject=" + subject + "&body=" + body;
    setSubmitted(true);
  };

  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(5,8,15,0.74)", backdropFilter: "blur(4px)", padding: 24 }}>
      <div onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true" style={{ width: "100%", maxWidth: 520, maxHeight: "90vh", overflow: "auto", background: "#0e1424", border: "1px solid rgba(96,165,250,0.28)", borderRadius: 16, boxShadow: "0 40px 90px -30px rgba(0,0,0,0.85)" }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, padding: "24px 26px 0" }}>
          <div>
            <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11, letterSpacing: "0.2em", color: "#60a5fa", marginBottom: 8 }}>GET IN TOUCH</div>
            <h3 style={{ margin: 0, fontFamily: "'Archivo',sans-serif", fontSize: 22, fontWeight: 800, color: "#fff" }}>Book a consultation</h3>
          </div>
          <button onClick={onClose} aria-label="Close" style={{ flex: "none", width: 34, height: 34, borderRadius: 9, border: "1px solid rgba(255,255,255,0.14)", background: "rgba(255,255,255,0.04)", color: "#c4cede", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="close" style={{ fontSize: 20 }} /></button>
        </div>

        {!submitted ? (
          <form onSubmit={handleSubmit} style={{ padding: "16px 26px 26px" }}>
            <p style={{ margin: "0 0 18px", fontSize: 13.5, lineHeight: 1.6, color: "#a7b3c6" }}>Tell us a bit about your business and we'll be in touch within one business day.</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <div><label style={labelStyle}>Full name</label><input name="name" required style={inputStyle} /></div>
              <div><label style={labelStyle}>Work email</label><input name="email" type="email" required style={inputStyle} /></div>
              <div><label style={labelStyle}>Company</label><input name="company" style={inputStyle} /></div>
              <div><label style={labelStyle}>Phone <span style={{ color: "#7f8ea3", fontWeight: 400 }}>(optional)</span></label><input name="phone" style={inputStyle} /></div>
            </div>
            <div style={{ marginTop: 14 }}><label style={labelStyle}>What can we help with?</label><select name="interest" style={inputStyle}>{CONSULT_INTERESTS.map((o) => <option key={o}>{o}</option>)}</select></div>
            <div style={{ marginTop: 14 }}><label style={labelStyle}>Message</label><textarea name="message" rows={3} style={{ ...inputStyle, resize: "vertical" }} /></div>
            <button type="submit" style={{ width: "100%", marginTop: 20, padding: 13, borderRadius: 10, background: ACCENT, border: "none", color: "#fff", fontFamily: "inherit", fontSize: 14.5, fontWeight: 600, cursor: "pointer" }}>Send request</button>
            <div style={{ textAlign: "center", marginTop: 12, fontSize: 12, color: "#7f8ea3" }}>Or email us directly at <span style={{ color: "#7cb0ff" }}>{CONSULT_EMAIL}</span></div>
          </form>
        ) : (
          <div style={{ padding: "34px 26px 40px", textAlign: "center" }}>
            <Icon name="check" style={{ fontSize: 30, width: 60, height: 60, borderRadius: "50%", background: "rgba(74,222,128,0.14)", color: "#4ade80", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 18px" }} />
            <h3 style={{ margin: 0, fontFamily: "'Archivo',sans-serif", fontSize: 20, fontWeight: 800, color: "#fff" }}>Your request is ready to send</h3>
            <p style={{ margin: "12px auto 0", maxWidth: 360, fontSize: 14, lineHeight: 1.6, color: "#a7b3c6" }}>We've opened an email to our team with your details. Send it from your mail app and we'll reply within one business day.</p>
            <button onClick={onClose} style={{ marginTop: 22, padding: "12px 24px", borderRadius: 10, background: ACCENT, border: "none", color: "#fff", fontFamily: "inherit", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>Done</button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function Homepage() {
  const [consultOpen, setConsultOpen] = React.useState(false);
  const openConsult = (e) => { if (e) e.preventDefault(); setConsultOpen(true); };
  const closeConsult = () => setConsultOpen(false);
  return (
    <div style={{ background: "#0c111e", color: "#eaf0fb", fontFamily: "'IBM Plex Sans',system-ui,sans-serif" }}>
      {/* NAV */}
      <header style={{ borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ maxWidth: 1320, margin: "0 auto", display: "flex", alignItems: "center", gap: 28, padding: "20px 48px" }}>
          <Logo />
          <div style={{ flex: 1 }} />
          <nav style={{ display: "flex", alignItems: "center", gap: 26, fontSize: 14, fontWeight: 500, color: "#c4cede" }}>
            <a href="#capabilities" style={{ color: "#c4cede", textDecoration: "none" }}>Services</a>
            <a href="#capabilities" style={{ color: "#c4cede", textDecoration: "none" }}>Solutions</a>
            <a href="#about" style={{ color: "#c4cede", textDecoration: "none" }}>About</a>
            <a href="#" onClick={openConsult} style={{ color: "#c4cede", textDecoration: "none", cursor: "pointer" }}>Contact</a>
          </nav>
          <a href="https://portal.haley365.com/" target="_blank" rel="noopener noreferrer" style={{ padding: "9px 16px", border: "1px solid rgba(255,255,255,0.2)", borderRadius: 9, fontSize: 13.5, fontWeight: 600, color: "#eaf0fb", textDecoration: "none" }}>
            Client Login
          </a>
          <a href="#" style={{ padding: "9px 18px", borderRadius: 9, background: ACCENT, fontSize: 13.5, fontWeight: 600, color: "#fff", textDecoration: "none" }}>
            Get started
          </a>
        </div>
      </header>

      {/* HERO */}
      <section style={{ position: "relative", overflow: "hidden", background: "radial-gradient(680px 420px at 50% -8%,rgba(59,130,246,0.28),transparent 70%)" }}>
        <div style={{ position: "absolute", inset: 0, backgroundImage: "linear-gradient(rgba(255,255,255,0.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.035) 1px,transparent 1px)", backgroundSize: "44px 44px", maskImage: "radial-gradient(560px 400px at 50% 20%,#000,transparent 75%)", WebkitMaskImage: "radial-gradient(560px 400px at 50% 20%,#000,transparent 75%)" }} />
        <div style={{ position: "relative", maxWidth: 1320, margin: "0 auto", padding: "96px 48px 88px", textAlign: "center" }}>
          <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 12.5, letterSpacing: "0.22em", color: "#60a5fa", marginBottom: 22 }}>
            MANAGED IT · SECURITY · CLOUD · AI
          </div>
          <h1 style={{ margin: "0 auto", maxWidth: 820, fontFamily: "'Archivo',sans-serif", fontSize: 58, lineHeight: 1.05, fontWeight: 800, letterSpacing: "-0.02em", color: "#fff" }}>
            Your IT partner, now AI-powered.
          </h1>
          <p style={{ margin: "22px auto 0", maxWidth: 620, fontSize: 18, lineHeight: 1.6, color: "#aeb9ca" }}>
            Haley365 keeps your business secure, current, and moving — combining managed IT and security with custom applications and cloud built around how you actually work.
          </p>
          <div style={{ display: "flex", gap: 14, justifyContent: "center", marginTop: 34 }}>
            <a href="#" onClick={openConsult} style={{ padding: "14px 26px", borderRadius: 11, background: ACCENT, fontSize: 15, fontWeight: 600, color: "#fff", textDecoration: "none", cursor: "pointer" }}>
              Book a consultation
            </a>
            <a href="#" style={{ padding: "14px 26px", borderRadius: 11, border: "1px solid rgba(255,255,255,0.22)", fontSize: 15, fontWeight: 600, color: "#eaf0fb", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 8 }}>
              Explore services <Icon name="arrow_forward" style={{ fontSize: 18 }} />
            </a>
          </div>
          <div style={{ display: "flex", justifyContent: "center", gap: 52, marginTop: 56 }}>
            {STATS.map((s, i) => (
              <div key={s.label} style={{ display: "flex", alignItems: "stretch", gap: 52 }}>
                {i > 0 && <div style={{ width: 1, background: "rgba(255,255,255,0.1)", marginLeft: -52 }} />}
                <div>
                  <div style={{ fontFamily: "'Archivo',sans-serif", fontSize: 26, fontWeight: 800, color: "#fff" }}>{s.value}</div>
                  <div style={{ fontSize: 12.5, color: "#8a97ab", marginTop: 4 }}>{s.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CAPABILITIES */}
      <section id="capabilities" style={{ maxWidth: 1320, margin: "0 auto", padding: "16px 48px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 18 }}>
          {CAPABILITIES.map((c) => (
            <div key={c.title} style={{ background: "rgba(59,130,246,0.09)", border: "1px solid rgba(96,165,250,0.22)", borderRadius: 14, padding: "26px 22px" }}>
              <Icon name={c.icon} style={{ fontSize: 24, width: 46, height: 46, borderRadius: 11, background: "rgba(96,165,250,0.16)", color: "#7cb0ff", display: "inline-flex", alignItems: "center", justifyContent: "center", marginBottom: 18 }} />
              <div style={{ fontFamily: "'Archivo',sans-serif", fontSize: 18, fontWeight: 700, color: "#fff" }}>{c.title}</div>
              <p style={{ margin: "9px 0 0", fontSize: 13.5, lineHeight: 1.6, color: "#a7b3c6" }}>{c.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* WHY / STORY */}
      <section style={{ borderTop: "1px solid rgba(255,255,255,0.07)", background: "#0a0f1a" }}>
        <div style={{ maxWidth: 1320, margin: "0 auto", padding: "70px 48px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 56, alignItems: "center" }}>
          <div>
            <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 12.5, letterSpacing: "0.2em", color: "#60a5fa", marginBottom: 16 }}>WHY HALEY365</div>
            <h2 style={{ margin: 0, fontFamily: "'Archivo',sans-serif", fontSize: 34, fontWeight: 800, lineHeight: 1.15, color: "#fff" }}>
              More than a service provider — a technology partner.
            </h2>
            <p style={{ margin: "18px 0 24px", fontSize: 15, lineHeight: 1.7, color: "#a7b3c6" }}>
              We pair the reliability of managed IT with the ambition of a modern software team. That means your security, your cloud, and the custom tools you run every day all come from one partner who knows your business.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
              {WHY_POINTS.map((p) => (
                <div key={p} style={{ display: "flex", alignItems: "center", gap: 11, fontSize: 14.5, color: "#d3dbe8" }}>
                  <Icon name="check_circle" style={{ fontSize: 20, color: "#4ade80" }} />
                  {p}
                </div>
              ))}
            </div>
          </div>
          {/* Product proof: a framed screenshot of the client portal dashboard */}
          <div style={{ position: "relative" }}>
            <div style={{ position: "absolute", inset: "-40px -30px", background: "radial-gradient(360px 260px at 65% 30%,rgba(59,130,246,0.4),transparent 70%)", filter: "blur(8px)" }} />
            <div style={{ position: "relative", borderRadius: 14, overflow: "hidden", border: "1px solid rgba(96,165,250,0.28)", boxShadow: "0 40px 80px -30px rgba(0,0,0,0.7),0 0 0 1px rgba(96,165,250,0.08)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "11px 14px", background: "#0a0f1a", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
                <span style={{ width: 11, height: 11, borderRadius: "50%", background: "#ff5f57" }} />
                <span style={{ width: 11, height: 11, borderRadius: "50%", background: "#febc2e" }} />
                <span style={{ width: 11, height: 11, borderRadius: "50%", background: "#28c840" }} />
                <span style={{ marginLeft: 10, fontFamily: "'IBM Plex Mono',monospace", fontSize: 11, color: "#7f8ea3" }}>portal.haley365.com</span>
              </div>
              {/* Replace with an optimized/next-gen image + next/image in production */}
              <img src="/assets/portal-preview.png" alt="Haley365 client portal dashboard" style={{ display: "block", width: "100%", height: "auto" }} />
            </div>
          </div>
        </div>
      </section>

      {/* ABOUT (nav "About" target) */}
      <section id="about" style={{ maxWidth: 1320, margin: "0 auto", padding: "84px 48px", borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ display: "grid", gridTemplateColumns: "0.85fr 1.15fr", gap: 56, alignItems: "start", marginBottom: 48 }}>
          <div>
            <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 12.5, letterSpacing: "0.2em", color: "#60a5fa", marginBottom: 16 }}>ABOUT HALEY365</div>
            <h2 style={{ margin: 0, fontFamily: "'Archivo',sans-serif", fontSize: 36, fontWeight: 800, lineHeight: 1.12, color: "#fff" }}>Two decades of IT, security, and custom software.</h2>
          </div>
          <div>
            <p style={{ margin: "0 0 18px", fontSize: 16, lineHeight: 1.75, color: "#a7b3c6" }}>For over 20 years, Haley365 has been the technology partner small and mid-sized businesses rely on. Our team brings more than 30 years of combined IT experience across networking, cloud, and security — and a security-first mindset shapes everything we do.</p>
            <p style={{ margin: 0, fontSize: 16, lineHeight: 1.75, color: "#a7b3c6" }}>We're also a company that specializes in custom solutions. For over 15 years we've built custom applications tailored to how our clients actually work — not off-the-shelf software bent to fit. When you work with Haley365, you work with senior engineers who know your environment.</p>
          </div>
        </div>

        {/* stat row */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 18, marginBottom: 40 }}>
          {ABOUT_STATS.map((s) => (
            <div key={s.label} style={{ background: "#0a0f1a", border: "1px solid rgba(96,165,250,0.16)", borderRadius: 14, padding: "26px 24px" }}>
              <div style={{ fontFamily: "'Archivo',sans-serif", fontSize: 38, fontWeight: 800, color: "#fff", lineHeight: 1 }}>{s.value}</div>
              <div style={{ marginTop: 8, fontSize: 13.5, color: "#a7b3c6" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* value cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 18, marginBottom: 40 }}>
          {ABOUT_VALUES.map((v) => (
            <div key={v.title} style={{ background: "#0e1424", border: "1px solid rgba(96,165,250,0.16)", borderRadius: 14, padding: "26px 24px" }}>
              <Icon name={v.icon} style={{ fontSize: 22, width: 44, height: 44, borderRadius: 11, background: "rgba(96,165,250,0.16)", color: "#7cb0ff", display: "inline-flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }} />
              <div style={{ fontFamily: "'Archivo',sans-serif", fontSize: 17, fontWeight: 700, color: "#fff" }}>{v.title}</div>
              <p style={{ margin: "8px 0 0", fontSize: 13.5, lineHeight: 1.6, color: "#a7b3c6" }}>{v.body}</p>
            </div>
          ))}
        </div>

        {/* certifications strip */}
        <div style={{ background: "#0a0f1a", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "24px 26px", display: "flex", alignItems: "center", gap: 26, flexWrap: "wrap" }}>
          <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11.5, letterSpacing: "0.2em", color: "#60a5fa", flex: "none" }}>CERTIFICATIONS &amp; EXPERTISE</div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", flex: 1 }}>
            {ABOUT_CERTS.map((c) => (
              <span key={c.label} style={{ display: "inline-flex", alignItems: "center", gap: 7, padding: "8px 14px", background: "rgba(96,165,250,0.1)", border: "1px solid rgba(96,165,250,0.2)", borderRadius: 999, fontSize: 13, fontWeight: 500, color: "#d3dbe8" }}>
                <Icon name={c.icon} style={{ fontSize: 16, color: "#7cb0ff" }} />{c.label}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ background: "radial-gradient(600px 300px at 50% 120%,rgba(59,130,246,0.25),transparent 70%),#0c111e" }}>
        <div style={{ maxWidth: 1320, margin: "0 auto", padding: "80px 48px", textAlign: "center" }}>
          <h2 style={{ margin: "0 auto", maxWidth: 640, fontFamily: "'Archivo',sans-serif", fontSize: 38, fontWeight: 800, color: "#fff", lineHeight: 1.12 }}>
            Ready to modernize your IT?
          </h2>
          <p style={{ margin: "16px auto 30px", maxWidth: 520, fontSize: 16, color: "#a7b3c6" }}>
            Let's talk about where AI, security, and cloud can take your business.
          </p>
          <a href="#" onClick={openConsult} style={{ display: "inline-block", padding: "15px 30px", borderRadius: 12, background: ACCENT, fontSize: 15.5, fontWeight: 600, color: "#fff", textDecoration: "none", cursor: "pointer" }}>
            Book a consultation
          </a>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ maxWidth: 1320, margin: "0 auto", padding: "26px 48px", display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 13, color: "#6f7c90" }}>
          <span>© 2026 Haley365 Information Security</span>
          <div style={{ display: "flex", gap: 16 }}>
            <Icon name="public" style={{ fontSize: 19 }} />
            <Icon name="mail" style={{ fontSize: 19 }} />
            <Icon name="call" style={{ fontSize: 19 }} />
          </div>
        </div>
      </footer>

      <ConsultModal open={consultOpen} onClose={closeConsult} />
    </div>
  );
}
