# Handoff: Haley365 Homepage (Direction 1a)

## Overview
A redesigned marketing homepage for **Haley365 Information Security**, an MSP evolving its positioning toward four balanced capabilities: **AI solutions & custom applications, managed security, cloud infrastructure, and managed IT / service desk**. This direction ("1a — Safe") intentionally *evolves* the current haley365.com look — the same dark-navy canvas and blue accent — rather than replacing it, so the brand stays recognizable while feeling modern and AI-forward. Target audience: **SMBs**.

## About the Design Files
The files in this bundle are **design references created in HTML/JSX** — a prototype showing the intended look, layout, copy, and spacing. They are **not** meant to be shipped verbatim. The task is to **recreate this design in the target codebase (React / Next.js)** using its established patterns, styling convention (Tailwind / CSS Modules / styled-components), routing, and component library.

Two references are provided:
- `homepage-1a-reference.html` — a standalone, browser-openable HTML rendering (exact visual truth).
- `Homepage.jsx` — a dependency-free React component that mirrors the design with inline styles and data-driven sections. Use it as a scaffold; convert inline styles to the project's convention.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final for this direction. Recreate pixel-accurately using the codebase's libraries. The only deliberate placeholder is the abstract visual in the "Why Haley365" band (a radial-glow panel with an icon) — keep abstract for now; real photography/illustration can be dropped in later.

## Screens / Views

### Homepage (single page, `/`)
Full-width dark page, centered content column capped at **1320px** (`margin: 0 auto`), horizontal padding **48px**. Sections top to bottom:

**1. Nav bar** — full-width, `border-bottom: 1px solid rgba(255,255,255,0.07)`.
- Left: logo lockup — circuit SVG glyph (blue `#3b82f6` strokes, white + blue nodes) + wordmark "HALEY365" (Archivo 800, letter-spacing 0.16em, 17px, white) with "INFORMATION SECURITY" beneath (8.5px, letter-spacing 0.26em, `#7f8ea3`).
- Right: text links Services / Solutions / About / Contact (14px, 500, `#c4cede`), then a **Client Login** outline button (border `rgba(255,255,255,0.2)`, radius 9) that routes to the client portal, then a **Get started** solid button (bg `#2f6bff`, radius 9).
- Row padding `20px 48px`, gap 28.

**2. Hero** — centered text, padding `96px 48px 88px`.
- Background: `radial-gradient(680px 420px at 50% -8%, rgba(59,130,246,0.28), transparent 70%)` plus a faint 44px grid overlay (`linear-gradient` lines at `rgba(255,255,255,0.035)`) masked with a radial fade. Decorative only.
- Eyebrow: "MANAGED IT · SECURITY · CLOUD · AI" (IBM Plex Mono, 12.5px, letter-spacing 0.22em, `#60a5fa`).
- H1: "Your IT partner, now AI-powered." (Archivo 800, **58px**, line-height 1.05, letter-spacing -0.02em, white, max-width 820).
- Sub: 18px, line-height 1.6, `#aeb9ca`, max-width 620.
- Buttons: "Book a consultation" (solid `#2f6bff`) + "Explore services →" (outline, arrow icon). Padding `14px 26px`, radius 11.
- Stat strip (margin-top 56, gap 52, vertical hairline dividers `rgba(255,255,255,0.1)`): **24/7** Security operations · **99.9%** Monitored uptime · **1,200+** Endpoints managed. Numbers Archivo 800 26px white; labels 12.5px `#8a97ab`.

**3. Capabilities** — 4-column grid (`repeat(4,1fr)`, gap 18), padding `16px 48px 80px`.
- Each card: bg `rgba(59,130,246,0.09)`, border `1px solid rgba(96,165,250,0.22)`, radius 14, padding `26px 22px`.
- Icon chip: 46×46, radius 11, bg `rgba(96,165,250,0.16)`, icon color `#7cb0ff`, 24px Material Symbol.
- Title: Archivo 700, 18px, white. Body: 13.5px, line-height 1.6, `#a7b3c6`.
- Cards (icon / title / body):
  1. `smart_toy` — **AI & Custom Apps** — "Custom software and AI workflows that automate the busywork and fit how your team operates."
  2. `shield` — **Managed Security** — "24/7 threat detection, EDR, and a hardened posture that keeps you audit-ready and protected."
  3. `cloud` — **Cloud Infrastructure** — "Design, migration, and management of resilient cloud environments that scale with you."
  4. `support_agent` — **Managed IT & Service Desk** — "A human-centric help desk that keeps your people productive and your systems current."

**4. Why Haley365** — two-column band (`1fr 1fr`, gap 56), bg `#0a0f1a`, top border `rgba(255,255,255,0.07)`, padding `70px 48px`.
- Left: eyebrow "WHY HALEY365" (Plex Mono, `#60a5fa`); H2 "More than a service provider — a technology partner." (Archivo 800, 34px, white); paragraph (15px, `#a7b3c6`); three check rows (`check_circle` icon `#4ade80`, 14.5px `#d3dbe8`): "One partner across IT, security, cloud, and software" / "SMB-focused, senior-level engineering" / "Transparent reporting through your client portal".
- Right: **placeholder** visual — `aspect-ratio 4/3`, radius 16, border `rgba(96,165,250,0.22)`, radial-glow bg over `#0e1424`, centered `insights` icon at `rgba(124,176,255,0.5)`. Swap for real imagery later.

**5. CTA** — centered, padding `80px 48px`, bg radial glow over `#0c111e`. H2 "Ready to modernize your IT?" (Archivo 800, 38px). Sub 16px `#a7b3c6`. Solid button "Book a consultation" (`#2f6bff`, radius 12).

**6. Footer** — top border, padding `26px 48px`, space-between. Left "© 2026 Haley365 Information Security" (13px `#6f7c90`). Right: `public` / `mail` / `call` icons (19px).

## Interactions & Behavior
- **Nav links / buttons** route to their sections/pages; "Client Login" → the MSP client portal (separate app).
- **Hover states** (add per codebase convention): buttons brighten (`filter: brightness(1.06)`); solid CTA `#2f6bff` → slightly lighter; outline buttons → border opacity up / subtle bg `rgba(255,255,255,0.06)`; nav links → white; capability cards → border `rgba(96,165,250,0.4)` + faint lift.
- **Responsive:** capabilities grid 4→2→1 columns; "Why" band stacks to 1 column under ~900px; hero H1 scales down (~clamp(36px, 6vw, 58px)); stat strip wraps. The reference is desktop (1320px); implement fluid breakpoints.
- No loading/error/form states on this page (CTAs link out to a contact/booking flow, not built here).

## State Management
None required — this is a static marketing page. No client state or data fetching. Can be a server component in Next.js app router.

## Design Tokens
**Colors**
- Page bg: `#0c111e`; alt section bg: `#0a0f1a`; panel bg: `#0e1424`
- Accent (primary/CTA): `#2f6bff`; logo/eyebrow blue: `#3b82f6` / `#60a5fa`; icon blue: `#7cb0ff`
- Text: white `#ffffff`; body `#a7b3c6` / `#aeb9ca`; muted `#8a97ab` / `#6f7c90`; nav link `#c4cede`; check green `#4ade80`
- Card bg: `rgba(59,130,246,0.09)`; card border: `rgba(96,165,250,0.22)`; hairlines: `rgba(255,255,255,0.07)`

**Typography**
- Display/headings: **Archivo** (700/800)
- Body/UI: **IBM Plex Sans** (400/500/600/700)
- Eyebrows/mono labels: **IBM Plex Mono** (500/600)
- Scale: H1 58 / H2 34–38 / card title 18 / body 15–18 / eyebrow 12.5 / caption 12.5–13.5

**Spacing** — section vertical padding 70–96px; horizontal 48px; grid/gap 18–56; container max 1320px.
**Radius** — buttons 9–12, cards 14–16. **Borders** — 1px translucent white/blue as above.

## Assets
- **Logo:** inline SVG in the reference (circuit-node glyph, kept from current brand). Replace with the official Haley365 logo SVG when available.
- **Icons:** Material Symbols Rounded (`smart_toy`, `shield`, `cloud`, `support_agent`, `check_circle`, `arrow_forward`, `insights`, `public`, `mail`, `call`). Swap for the project's icon set if preferred.
- **Fonts:** Google Fonts (Archivo, IBM Plex Sans, IBM Plex Mono). Prefer `next/font/google` in Next.js.
- **Imagery:** none yet — the "Why" panel is an intentional abstract placeholder.

## Files
- `design_handoff_haley365_homepage/homepage-1a-reference.html` — standalone visual reference (open in a browser).
- `design_handoff_haley365_homepage/Homepage.jsx` — React scaffold (inline styles, data-driven).
- `Haley365 Homepage.dc.html` (project root) — original exploration with all three directions (1a / 1b / 1c) for context.

## Notes for implementation
- Recommended structure: `app/page.jsx` (or `.tsx`) composing small components — `<Nav/>`, `<Hero/>`, `<Capabilities/>`, `<WhyUs/>`, `<CTA/>`, `<Footer/>`. Keep `CAPABILITIES`, `STATS`, `WHY_POINTS` as data arrays (already in `Homepage.jsx`).
- If using Tailwind, map the tokens above to `tailwind.config` theme extensions (colors, fontFamily) and convert inline styles to utility classes.
- Load fonts via `next/font/google` for best performance; keep Material Symbols via `<link>` or migrate to an icon component.
- This is direction **1a** only. Directions **1b** (modern-tech / bento) and **1c** (bold / AI-forward) also exist in the exploration file if you want to pull elements from them later.
