/**
 * Haley365 — Homepage (Direction 1a: "Safe / evolve current")
 * ------------------------------------------------------------
 * Production-ready React component. Framework-agnostic (works in Next.js
 * app router as app/page.jsx, or as a component in any React app).
 *
 * FONTS: load these once (e.g. in app/layout.jsx <head> or via next/font):
 *   Archivo (600/700/800), IBM Plex Sans (400/500/600/700), IBM Plex Mono (500/600)
 *   Material Symbols Rounded (for icons)
 *   <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;700;800&family=IBM+Plex+Mono:wght@500;600&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet" />
 *   <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
 *
 * ADAPTATION NOTES for Claude Code:
 *   - Inline styles are used for a faithful, dependency-free reference.
 *     Convert to your project's convention (Tailwind classes / CSS Modules /
 *     styled-components). The exact token values are in the handoff README.
 *   - Replace <Icon/> (Material Symbols) with your icon library if preferred.
 *   - Wire the CTAs / nav links to real routes. "Client Login" -> portal.
 *   - The hero grid overlay + radial glows are decorative; keep as CSS.
 */

const ACCENT = "#2f6bff";

const CAPABILITIES = [
  {
    icon: "smart_toy",
    title: "AI & Custom Apps",
    body: "Custom software and AI workflows that automate the busywork and fit how your team operates.",
  },
  {
    icon: "shield",
    title: "Managed Security",
    body: "24/7 threat detection, EDR, and a hardened posture that keeps you audit-ready and protected.",
  },
  {
    icon: "cloud",
    title: "Cloud Infrastructure",
    body: "Design, migration, and management of resilient cloud environments that scale with you.",
  },
  {
    icon: "support_agent",
    title: "Managed IT & Service Desk",
    body: "A human-centric help desk that keeps your people productive and your systems current.",
  },
];

const STATS = [
  { value: "24/7", label: "Security operations" },
  { value: "99.9%", label: "Monitored uptime" },
  { value: "1,200+", label: "Endpoints managed" },
];

const WHY_POINTS = [
  "One partner across IT, security, cloud, and software",
  "SMB-focused, senior-level engineering",
  "Transparent reporting through your client portal",
];

function Icon({ name, style }) {
  return (
    <span
      className="material-symbols-rounded"
      style={{ fontFamily: "'Material Symbols Rounded'", lineHeight: 1, ...style }}
    >
      {name}
    </span>
  );
}

function Logo() {
  return (
    <a href="/" style={{ display: "flex", alignItems: "center", gap: 11, textDecoration: "none" }}>
      <svg width="38" height="30" viewBox="0 0 48 38" fill="none" style={{ flex: "none" }}>
        <g stroke="#3b82f6" strokeWidth="2.2" strokeLinecap="round">
          <line x1="6" y1="19" x2="20" y2="8" />
          <line x1="6" y1="19" x2="20" y2="30" />
          <line x1="20" y1="8" x2="38" y2="14" />
          <line x1="20" y1="30" x2="38" y2="24" />
          <line x1="38" y1="14" x2="38" y2="24" />
        </g>
        <g fill="#fff">
          <circle cx="6" cy="19" r="3.4" />
          <circle cx="20" cy="8" r="3.4" />
          <circle cx="20" cy="30" r="3.4" />
        </g>
        <g fill="#3b82f6">
          <circle cx="38" cy="14" r="3.4" />
          <circle cx="38" cy="24" r="3.4" />
        </g>
      </svg>
      <span style={{ display: "flex", flexDirection: "column", lineHeight: 1 }}>
        <span style={{ fontFamily: "'Archivo',sans-serif", fontWeight: 800, letterSpacing: "0.16em", fontSize: 17, color: "#fff" }}>
          HALEY365
        </span>
        <span style={{ fontSize: 8.5, letterSpacing: "0.26em", color: "#7f8ea3", marginTop: 4 }}>
          INFORMATION SECURITY
        </span>
      </span>
    </a>
  );
}

export default function Homepage() {
  return (
    <div style={{ background: "#0c111e", color: "#eaf0fb", fontFamily: "'IBM Plex Sans',system-ui,sans-serif" }}>
      {/* NAV */}
      <header style={{ borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ maxWidth: 1320, margin: "0 auto", display: "flex", alignItems: "center", gap: 28, padding: "20px 48px" }}>
          <Logo />
          <div style={{ flex: 1 }} />
          <nav style={{ display: "flex", alignItems: "center", gap: 26, fontSize: 14, fontWeight: 500, color: "#c4cede" }}>
            <a href="#" style={{ color: "#c4cede", textDecoration: "none" }}>Services</a>
            <a href="#" style={{ color: "#c4cede", textDecoration: "none" }}>Solutions</a>
            <a href="#" style={{ color: "#c4cede", textDecoration: "none" }}>About</a>
            <a href="#" style={{ color: "#c4cede", textDecoration: "none" }}>Contact</a>
          </nav>
          <a href="#" style={{ padding: "9px 16px", border: "1px solid rgba(255,255,255,0.2)", borderRadius: 9, fontSize: 13.5, fontWeight: 600, color: "#eaf0fb", textDecoration: "none" }}>
            Client Login
          </a>
          <a href="#" style={{ padding: "9px 18px", borderRadius: 9, background: ACCENT, fontSize: 13.5, fontWeight: 600, color: "#fff", textDecoration: "none" }}>
            Get started
          </a>
        </div>
      </header>

      {/* HERO */}
      <section style={{ position: "relative", overflow: "hidden", background: "radial-gradient(680px 420px at 50% -8%,rgba(59,130,246,0.28),transparent 70%)" }}>
        <div style={{ position: "absolute", inset: 0, backgroundImage: "linear-gradient(rgba(255,255,255,0.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.035) 1px,transparent 1px)", backgroundSize: "44px 44px", maskImage: "radial-gradient(560px 400px at 50% 20%,#000,transparent 75%)", WebkitMaskImage: "radial-gradient(560px 400px at 50% 20%,#000,transparent 75%)" }} />
        <div style={{ position: "relative", maxWidth: 1320, margin: "0 auto", padding: "96px 48px 88px", textAlign: "center" }}>
          <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 12.5, letterSpacing: "0.22em", color: "#60a5fa", marginBottom: 22 }}>
            MANAGED IT · SECURITY · CLOUD · AI
          </div>
          <h1 style={{ margin: "0 auto", maxWidth: 820, fontFamily: "'Archivo',sans-serif", fontSize: 58, lineHeight: 1.05, fontWeight: 800, letterSpacing: "-0.02em", color: "#fff" }}>
            Your IT partner, now AI-powered.
          </h1>
          <p style={{ margin: "22px auto 0", maxWidth: 620, fontSize: 18, lineHeight: 1.6, color: "#aeb9ca" }}>
            Haley365 keeps your business secure, current, and moving — combining managed IT and security with custom applications and cloud built around how you actually work.
          </p>
          <div style={{ display: "flex", gap: 14, justifyContent: "center", marginTop: 34 }}>
            <a href="#" style={{ padding: "14px 26px", borderRadius: 11, background: ACCENT, fontSize: 15, fontWeight: 600, color: "#fff", textDecoration: "none" }}>
              Book a consultation
            </a>
            <a href="#" style={{ padding: "14px 26px", borderRadius: 11, border: "1px solid rgba(255,255,255,0.22)", fontSize: 15, fontWeight: 600, color: "#eaf0fb", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 8 }}>
              Explore services <Icon name="arrow_forward" style={{ fontSize: 18 }} />
            </a>
          </div>
          <div style={{ display: "flex", justifyContent: "center", gap: 52, marginTop: 56 }}>
            {STATS.map((s, i) => (
              <div key={s.label} style={{ display: "flex", alignItems: "stretch", gap: 52 }}>
                {i > 0 && <div style={{ width: 1, background: "rgba(255,255,255,0.1)", marginLeft: -52 }} />}
                <div>
                  <div style={{ fontFamily: "'Archivo',sans-serif", fontSize: 26, fontWeight: 800, color: "#fff" }}>{s.value}</div>
                  <div style={{ fontSize: 12.5, color: "#8a97ab", marginTop: 4 }}>{s.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CAPABILITIES */}
      <section style={{ maxWidth: 1320, margin: "0 auto", padding: "16px 48px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 18 }}>
          {CAPABILITIES.map((c) => (
            <div key={c.title} style={{ background: "rgba(59,130,246,0.09)", border: "1px solid rgba(96,165,250,0.22)", borderRadius: 14, padding: "26px 22px" }}>
              <Icon name={c.icon} style={{ fontSize: 24, width: 46, height: 46, borderRadius: 11, background: "rgba(96,165,250,0.16)", color: "#7cb0ff", display: "inline-flex", alignItems: "center", justifyContent: "center", marginBottom: 18 }} />
              <div style={{ fontFamily: "'Archivo',sans-serif", fontSize: 18, fontWeight: 700, color: "#fff" }}>{c.title}</div>
              <p style={{ margin: "9px 0 0", fontSize: 13.5, lineHeight: 1.6, color: "#a7b3c6" }}>{c.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* WHY / STORY */}
      <section style={{ borderTop: "1px solid rgba(255,255,255,0.07)", background: "#0a0f1a" }}>
        <div style={{ maxWidth: 1320, margin: "0 auto", padding: "70px 48px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 56, alignItems: "center" }}>
          <div>
            <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 12.5, letterSpacing: "0.2em", color: "#60a5fa", marginBottom: 16 }}>WHY HALEY365</div>
            <h2 style={{ margin: 0, fontFamily: "'Archivo',sans-serif", fontSize: 34, fontWeight: 800, lineHeight: 1.15, color: "#fff" }}>
              More than a service provider — a technology partner.
            </h2>
            <p style={{ margin: "18px 0 24px", fontSize: 15, lineHeight: 1.7, color: "#a7b3c6" }}>
              We pair the reliability of managed IT with the ambition of a modern software team. That means your security, your cloud, and the custom tools you run every day all come from one partner who knows your business.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
              {WHY_POINTS.map((p) => (
                <div key={p} style={{ display: "flex", alignItems: "center", gap: 11, fontSize: 14.5, color: "#d3dbe8" }}>
                  <Icon name="check_circle" style={{ fontSize: 20, color: "#4ade80" }} />
                  {p}
                </div>
              ))}
            </div>
          </div>
          <div style={{ aspectRatio: "4 / 3", borderRadius: 16, border: "1px solid rgba(96,165,250,0.22)", background: "radial-gradient(400px 300px at 70% 20%,rgba(59,130,246,0.35),transparent 70%),#0e1424", display: "flex", alignItems: "center", justifyContent: "center" }}>
            {/* Placeholder abstract visual — swap for real imagery later */}
            <Icon name="insights" style={{ fontSize: 64, color: "rgba(124,176,255,0.5)" }} />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ background: "radial-gradient(600px 300px at 50% 120%,rgba(59,130,246,0.25),transparent 70%),#0c111e" }}>
        <div style={{ maxWidth: 1320, margin: "0 auto", padding: "80px 48px", textAlign: "center" }}>
          <h2 style={{ margin: "0 auto", maxWidth: 640, fontFamily: "'Archivo',sans-serif", fontSize: 38, fontWeight: 800, color: "#fff", lineHeight: 1.12 }}>
            Ready to modernize your IT?
          </h2>
          <p style={{ margin: "16px auto 30px", maxWidth: 520, fontSize: 16, color: "#a7b3c6" }}>
            Let's talk about where AI, security, and cloud can take your business.
          </p>
          <a href="#" style={{ display: "inline-block", padding: "15px 30px", borderRadius: 12, background: ACCENT, fontSize: 15.5, fontWeight: 600, color: "#fff", textDecoration: "none" }}>
            Book a consultation
          </a>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ maxWidth: 1320, margin: "0 auto", padding: "26px 48px", display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 13, color: "#6f7c90" }}>
          <span>© 2026 Haley365 Information Security</span>
          <div style={{ display: "flex", gap: 16 }}>
            <Icon name="public" style={{ fontSize: 19 }} />
            <Icon name="mail" style={{ fontSize: 19 }} />
            <Icon name="call" style={{ fontSize: 19 }} />
          </div>
        </div>
      </footer>
    </div>
  );
}
